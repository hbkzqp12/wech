// 游戏入口文件
import './js/main.js'


