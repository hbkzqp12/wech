/**
 * 八路军打鬼子 - 微信小游戏入口
 */
require('./js/main.js');
