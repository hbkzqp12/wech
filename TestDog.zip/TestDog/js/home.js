/**
 * 首页：标题、当前积分、开始游戏、积分兑换（一次减 1000）
 */
const utils = require('./utils.js');

function HomeScene(opts) {
  this.getCtx = opts.getCtx;
  this.getSize = opts.getSize;
  this.setScene = opts.setScene;
  this.exchangeTip = '';
}

HomeScene.prototype.onEnter = function () {
  this.exchangeTip = '';
};

HomeScene.prototype.onLeave = function () {};

HomeScene.prototype.update = function () {
  const ctx = this.getCtx();
  const { width, height } = this.getSize();
  const total = utils.getTotalScore();

  // 背景
  ctx.fillStyle = '#2d5016';
  ctx.fillRect(0, 0, width, height);

  // 标题
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 28px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('八路军打鬼子', width / 2, 80);

  ctx.font = '16px sans-serif';
  ctx.fillText('点击「开始游戏」进入关卡', width / 2, 115);

  // 当前积分
  ctx.fillStyle = '#ffd700';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('当前积分：' + total, width / 2, 175);

  // 开始游戏按钮
  this.drawButton(width / 2, 260, 200, 50, '开始游戏', '#c41e3a');

  // 积分兑换按钮（一次减少 1000 积分）
  this.drawButton(width / 2, 330, 200, 50, '积分兑换 ( -1000 )', '#1a5490');
  ctx.font = '14px sans-serif';
  ctx.fillStyle = '#fff';
  ctx.fillText('积分≥1000 时可兑换', width / 2, 395);
  if (this.exchangeTip) {
    ctx.fillStyle = this.exchangeTip === 'ok' ? '#7fff00' : '#ff6b6b';
    ctx.fillText(this.exchangeTip === 'ok' ? '兑换成功！' : '积分不足 1000', width / 2, 420);
  }
};

HomeScene.prototype.drawButton = function (cx, cy, w, h, text, bgColor) {
  const ctx = this.getCtx();
  const { width } = this.getSize();
  const x = cx - w / 2;
  const y = cy - h / 2;
  this._btnStart = this._btnStart || { x, y, w, h, id: 'start' };
  this._btnExchange = this._btnExchange || { x: width / 2 - 100, y: 305, w: 200, h: 50, id: 'exchange' };
  if (text === '开始游戏') {
    this._btnStart.x = x;
    this._btnStart.y = y;
    this._btnStart.w = w;
    this._btnStart.h = h;
  } else {
    this._btnExchange.x = x;
    this._btnExchange.y = y;
    this._btnExchange.w = w;
    this._btnExchange.h = h;
  }
  ctx.fillStyle = bgColor;
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = '18px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, cx, cy);
};

HomeScene.prototype.hitTest = function (x, y) {
  const b1 = this._btnStart;
  const b2 = this._btnExchange;
  if (b1 && x >= b1.x && x <= b1.x + b1.w && y >= b1.y && y <= b1.y + b1.h) return 'start';
  if (b2 && x >= b2.x && x <= b2.x + b2.w && y >= b2.y && y <= b2.y + b2.h) return 'exchange';
  return null;
};

HomeScene.prototype.onTouchEnd = function (e) {
  const touch = e.changedTouches && e.changedTouches[0];
  if (!touch) return;
  const { width, height } = this.getSize();
  const x = touch.clientX != null ? touch.clientX : touch.x;
  const y = touch.clientY != null ? touch.clientY : touch.y;
  const id = this.hitTest(x, y);
  if (id === 'start') {
    this.setScene('play', { level: 1 });
  } else if (id === 'exchange') {
    const ok = utils.tryExchange();
    this.exchangeTip = ok ? 'ok' : 'no';
  }
};

module.exports = HomeScene;
