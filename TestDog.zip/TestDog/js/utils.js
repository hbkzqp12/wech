/**
 * 工具：积分本地存储
 */
const SCORE_KEY = 'game_total_score';
const EXCHANGE_KEY = 'game_exchange_count';

function getTotalScore() {
  try {
    return parseInt(wx.getStorageSync(SCORE_KEY) || '0', 10);
  } catch (e) {
    return 0;
  }
}

function setTotalScore(score) {
  try {
    wx.setStorageSync(SCORE_KEY, Math.max(0, score));
  } catch (e) {}
}

function addScore(delta) {
  const total = getTotalScore() + delta;
  setTotalScore(total);
  return total;
}

/** 积分兑换：一次扣 1000，返回是否成功 */
function tryExchange() {
  const total = getTotalScore();
  if (total < 1000) return false;
  setTotalScore(total - 1000);
  try {
    const count = parseInt(wx.getStorageSync(EXCHANGE_KEY) || '0', 10);
    wx.setStorageSync(EXCHANGE_KEY, count + 1);
  } catch (e) {}
  return true;
}

function getExchangeCount() {
  try {
    return parseInt(wx.getStorageSync(EXCHANGE_KEY) || '0', 10);
  } catch (e) {
    return 0;
  }
}

module.exports = {
  getTotalScore,
  setTotalScore,
  addScore,
  tryExchange,
  getExchangeCount
};
