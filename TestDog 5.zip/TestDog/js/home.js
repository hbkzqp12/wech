/**
 * 首页：标题、当前积分、军功章数、开始游戏、兑换军功章（1000 积分换 1 枚）
 */
const utils = require('./utils.js');

function HomeScene(opts) {
  this.getCtx = opts.getCtx;
  this.getSize = opts.getSize;
  this.setScene = opts.setScene;
  this.exchangeTip = '';
}

HomeScene.prototype.onEnter = function () {
  this.exchangeTip = '';
};

HomeScene.prototype.onLeave = function () {};

HomeScene.prototype.update = function () {
  const ctx = this.getCtx();
  const { width, height } = this.getSize();
  const total = utils.getTotalScore();
  const medals = utils.getExchangeCount();

  // 用画布实际尺寸整屏清空，避免从游戏返回后右下角残留白点
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#2d5016';
  if (ctx.canvas) {
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  } else {
    ctx.fillRect(0, 0, width, height);
  }

  // 标题
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 28px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('健脑打地鼠', width / 2, 80);

  ctx.font = '16px sans-serif';
  ctx.fillText('点击「开始游戏」进入关卡', width / 2, 115);

  // 当前积分
  ctx.fillStyle = '#ffd700';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('当前积分：' + total, width / 2, 165);

  // 军功章计数
  ctx.fillStyle = '#e6b800';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('军功章：' + medals + ' 枚', width / 2, 200);

  // 开始游戏按钮
  this.drawButton(width / 2, 270, 200, 50, '开始游戏', '#c41e3a');

  // 兑换军功章按钮（1000 积分换 1 枚）
  this.drawButton(width / 2, 340, 200, 50, '兑换军功章', '#1a5490');
  ctx.font = '14px sans-serif';
  ctx.fillStyle = '#fff';
  ctx.fillText('消耗 1000 积分兑换 1 枚军功章', width / 2, 405);
  if (this.exchangeTip) {
    ctx.fillStyle = this.exchangeTip === 'ok' ? '#7fff00' : '#ff6b6b';
    ctx.fillText(this.exchangeTip === 'ok' ? '获得 1 枚军功章！' : '积分不足 1000', width / 2, 430);
  }
};

HomeScene.prototype.drawButton = function (cx, cy, w, h, text, bgColor) {
  const ctx = this.getCtx();
  const { width } = this.getSize();
  const x = cx - w / 2;
  const y = cy - h / 2;
  this._btnStart = this._btnStart || { x, y, w, h, id: 'start' };
  this._btnExchange = this._btnExchange || { x: width / 2 - 100, y: 315, w: 200, h: 50, id: 'exchange' };
  if (text === '开始游戏') {
    this._btnStart.x = x;
    this._btnStart.y = y;
    this._btnStart.w = w;
    this._btnStart.h = h;
  } else {
    this._btnExchange.x = x;
    this._btnExchange.y = y;
    this._btnExchange.w = w;
    this._btnExchange.h = h;
  }
  ctx.fillStyle = bgColor;
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = '18px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, cx, cy);
};

HomeScene.prototype.hitTest = function (x, y) {
  const b1 = this._btnStart;
  const b2 = this._btnExchange;
  if (b1 && x >= b1.x && x <= b1.x + b1.w && y >= b1.y && y <= b1.y + b1.h) return 'start';
  if (b2 && x >= b2.x && x <= b2.x + b2.w && y >= b2.y && y <= b2.y + b2.h) return 'exchange';
  return null;
};

HomeScene.prototype.onTouchEnd = function (e) {
  const touch = e.changedTouches && e.changedTouches[0];
  if (!touch) return;
  const { width, height } = this.getSize();
  const x = touch.clientX != null ? touch.clientX : touch.x;
  const y = touch.clientY != null ? touch.clientY : touch.y;
  const id = this.hitTest(x, y);
  if (id === 'start') {
    this.setScene('play', { level: utils.getCurrentLevel() });
  } else if (id === 'exchange') {
    const ok = utils.tryExchange();
    this.exchangeTip = ok ? 'ok' : 'no';
  }
};

module.exports = HomeScene;
