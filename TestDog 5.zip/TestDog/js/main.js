/**
 * 主入口：画布、场景切换、触摸
 */
const HomeScene = require('./home.js');
const PlayScene = require('./play.js');

let canvas;
let ctx;
let width;
let height;
let safeTop;
let safeBottom;
let currentScene;
let homeScene;
let playScene;

function getCanvas() {
  if (canvas) return canvas;
  const sys = wx.getSystemInfoSync();
  canvas = wx.createCanvas();
  ctx = canvas.getContext('2d');
  width = sys.windowWidth || canvas.width;
  height = sys.windowHeight || canvas.height;
  safeTop = (sys.safeArea && sys.safeArea.top) != null ? sys.safeArea.top : (sys.statusBarHeight || 20);
  safeBottom = (sys.safeArea && sys.safeArea.bottom) != null ? (height - sys.safeArea.bottom) : 0;
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function getCtx() {
  if (!ctx) getCanvas();
  return ctx;
}

function getSize() {
  if (!width) getCanvas();
  return { width, height, safeTop: safeTop || 0, safeBottom: safeBottom || 0 };
}

function setScene(name, data) {
  if (currentScene && currentScene.onLeave) currentScene.onLeave();
  if (name === 'home') {
    var c = getCanvas();
    var g = getCtx();
    if (c && g) {
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.fillStyle = '#2d5016';
      g.fillRect(0, 0, c.width, c.height);
    }
    homeScene = homeScene || new HomeScene({ getCtx, getSize, setScene });
    currentScene = homeScene;
    currentScene.onEnter(data || {});
  } else if (name === 'play') {
    playScene = playScene || new PlayScene({ getCtx, getSize, setScene });
    currentScene = playScene;
    currentScene.onEnter(data || {});
  }
}

function loop() {
  if (currentScene && currentScene.update) {
    currentScene.update();
  }
  requestAnimationFrame(loop);
}

function onTouchStart(e) {
  if (currentScene && currentScene.onTouchStart) {
    currentScene.onTouchStart(e);
  }
}

function onTouchMove(e) {
  if (currentScene && currentScene.onTouchMove) {
    currentScene.onTouchMove(e);
  }
}

function onTouchEnd(e) {
  if (currentScene && currentScene.onTouchEnd) {
    currentScene.onTouchEnd(e);
  }
}

wx.onTouchStart(onTouchStart);
wx.onTouchMove(onTouchMove);
wx.onTouchEnd(onTouchEnd);

getCanvas();
setScene('home');
loop();
