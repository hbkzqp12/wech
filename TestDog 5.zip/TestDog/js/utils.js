/**
 * 工具：积分、关卡等本地存储
 */
const SCORE_KEY = 'game_total_score';
const EXCHANGE_KEY = 'game_exchange_count';
const LEVEL_KEY = 'game_current_level';

function getTotalScore() {
  try {
    return parseInt(wx.getStorageSync(SCORE_KEY) || '0', 10);
  } catch (e) {
    return 0;
  }
}

function setTotalScore(score) {
  try {
    wx.setStorageSync(SCORE_KEY, Math.max(0, score));
  } catch (e) {}
}

function addScore(delta) {
  const total = getTotalScore() + delta;
  setTotalScore(total);
  return total;
}

/** 兑换军功章：消耗 1000 积分兑换 1 枚军功章，返回是否成功 */
function tryExchange() {
  const total = getTotalScore();
  if (total < 1000) return false;
  setTotalScore(total - 1000);
  try {
    const count = parseInt(wx.getStorageSync(EXCHANGE_KEY) || '0', 10);
    wx.setStorageSync(EXCHANGE_KEY, count + 1);
  } catch (e) {}
  return true;
}

/** 军功章数量（即已兑换次数） */
function getExchangeCount() {
  try {
    return parseInt(wx.getStorageSync(EXCHANGE_KEY) || '0', 10);
  } catch (e) {
    return 0;
  }
}

/** 当前关卡（回到首页后再开始游戏时从此关继续） */
function getCurrentLevel() {
  try {
    return Math.max(1, parseInt(wx.getStorageSync(LEVEL_KEY) || '1', 10));
  } catch (e) {
    return 1;
  }
}

function setCurrentLevel(level) {
  try {
    wx.setStorageSync(LEVEL_KEY, Math.max(1, level));
  } catch (e) {}
}

module.exports = {
  getTotalScore,
  setTotalScore,
  addScore,
  tryExchange,
  getExchangeCount,
  getCurrentLevel,
  setCurrentLevel
};
