/**
 * 健脑打地鼠 - 微信小游戏入口
 */
require('./js/main.js');
