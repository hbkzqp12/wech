/**
 * 广告封装：激励视频（每关）、游戏界面上下横幅
 * 请在微信公众平台创建广告位后，将下面的 adUnitId 替换为真实 ID
 */
const REWARDED_VIDEO_AD_UNIT_ID = 'adunit-xxxxxxxx'; // 激励视频广告位 ID，需在后台创建后替换
const BANNER_AD_UNIT_ID = 'adunit-yyyyyyyy';         // Banner 广告位 ID，需在后台创建后替换

const BANNER_HEIGHT = 50;
const BANNER_WIDTH = 320;

let rewardedVideoAd = null;
let topBannerAd = null;
let bottomBannerAd = null;

function getSystemInfo() {
  try {
    return wx.getSystemInfoSync();
  } catch (e) {
    return { windowWidth: 375, windowHeight: 667 };
  }
}

/** 创建并返回激励视频单例 */
function getRewardedVideoAd() {
  if (rewardedVideoAd) return rewardedVideoAd;
  try {
    rewardedVideoAd = wx.createRewardedVideoAd({ adUnitId: REWARDED_VIDEO_AD_UNIT_ID });
    rewardedVideoAd.onError(function (err) {
      console.warn('激励视频广告错误', err);
    });
  } catch (e) {
    console.warn('创建激励视频失败', e);
  }
  return rewardedVideoAd;
}

/**
 * 播放激励视频，返回 Promise：播放结束或关闭后 resolve，拉取/播放失败也 resolve（不阻塞游戏）
 */
function showRewardedVideo() {
  const ad = getRewardedVideoAd();
  if (!ad) return Promise.resolve();
  return ad.show().catch(function (err) {
    return ad.load().then(function () { return ad.show(); });
  }).catch(function () {
    return Promise.resolve();
  });
}

/** 显示游戏界面上边栏 Banner */
function showTopBanner() {
  hideTopBanner();
  try {
    const sys = getSystemInfo();
    const w = Math.min(BANNER_WIDTH, sys.windowWidth || 375);
    const left = ((sys.windowWidth || 375) - w) / 2;
    topBannerAd = wx.createBannerAd({
      adUnitId: BANNER_AD_UNIT_ID,
      style: { left: left, top: 0, width: w }
    });
    topBannerAd.onError(function (err) { console.warn('顶部 Banner 错误', err); });
    topBannerAd.show().catch(function () {});
  } catch (e) {
    console.warn('创建顶部 Banner 失败', e);
  }
}

/** 显示游戏界面下边栏 Banner */
function showBottomBanner() {
  hideBottomBanner();
  try {
    const sys = getSystemInfo();
    const h = sys.windowHeight || 667;
    const w = Math.min(BANNER_WIDTH, sys.windowWidth || 375);
    const left = ((sys.windowWidth || 375) - w) / 2;
    bottomBannerAd = wx.createBannerAd({
      adUnitId: BANNER_AD_UNIT_ID,
      style: { left: left, top: h - BANNER_HEIGHT, width: w }
    });
    bottomBannerAd.onError(function (err) { console.warn('底部 Banner 错误', err); });
    bottomBannerAd.show().catch(function () {});
  } catch (e) {
    console.warn('创建底部 Banner 失败', e);
  }
}

function hideTopBanner() {
  if (topBannerAd) {
    try { topBannerAd.hide(); topBannerAd.destroy(); } catch (e) {}
    topBannerAd = null;
  }
}

function hideBottomBanner() {
  if (bottomBannerAd) {
    try { bottomBannerAd.hide(); bottomBannerAd.destroy(); } catch (e) {}
    bottomBannerAd = null;
  }
}

/** 隐藏并销毁游戏界面上下 Banner（离开游戏场景时调用） */
function hidePlayBanners() {
  hideTopBanner();
  hideBottomBanner();
}

/** 获取 Banner 占位高度，用于游戏内容避开遮挡 */
function getBannerHeight() {
  return BANNER_HEIGHT;
}

module.exports = {
  showRewardedVideo,
  showTopBanner,
  showBottomBanner,
  hidePlayBanners,
  getBannerHeight
};
