/**
 * 关卡场景：每关 20 个目标，1–5 关速度递增，第 6 关与第 1 关相同；打中一个 1 积分；过关后点「下一关」
 * 每关开始前播放激励视频，游戏界面上下显示横幅广告
 */
const utils = require('./utils.js');
const ads = require('./ads.js');

const TARGETS_PER_LEVEL = 20;
const COLS = 3;
const ROWS = 3;
const HOLE_COUNT = 9;

function PlayScene(opts) {
  this.getCtx = opts.getCtx;
  this.getSize = opts.getSize;
  this.setScene = opts.setScene;
  this.level = 1;
  this.spawned = 0;
  this.hitCount = 0;
  this.holes = [];
  this.nextSpawnTime = 0;
  this.showNextBtn = false;
  this.nextBtn = null;
  this.guziImage = null;
  this._guziImageLoaded = false;
  this.waitingForVideo = false;
  this._loadGuziImage();
}

/** 加载鬼子卡通图片，可选：将图片放到 images/guzi.png */
PlayScene.prototype._loadGuziImage = function () {
  if (this.guziImage) return;
  try {
    const img = wx.createImage();
    img.onload = function () { this._guziImageLoaded = true; }.bind(this);
    img.onerror = function () { this._guziImageLoaded = false; }.bind(this);
    img.src = 'images/guzi.png';
    this.guziImage = img;
  } catch (e) {
    this._guziImageLoaded = false;
  }
};

/** 绘制卡通搞笑鬼子脸（无文字），当未使用图片时作为替代 */
PlayScene.prototype.drawCartoonGuzi = function (ctx, cx, cy, radius) {
  const r = radius;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.fillStyle = '#f4d03f';
  ctx.strokeStyle = '#d4a017';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#333';
  ctx.beginPath();
  ctx.arc(-r * 0.3, -r * 0.1, r * 0.2, 0, Math.PI * 2);
  ctx.arc(r * 0.3, -r * 0.1, r * 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(-r * 0.28, -r * 0.15, r * 0.08, 0, Math.PI * 2);
  ctx.arc(r * 0.32, -r * 0.15, r * 0.08, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#8b4513';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-r * 0.5, r * 0.15);
  ctx.quadraticCurveTo(-r * 0.2, r * 0.5, 0, r * 0.35);
  ctx.quadraticCurveTo(r * 0.2, r * 0.5, r * 0.5, r * 0.15);
  ctx.stroke();
  ctx.restore();
};

PlayScene.prototype.onEnter = function (data) {
  this.level = data.level || 1;
  this.spawned = 0;
  this.hitCount = 0;
  this.holes = [];
  for (let i = 0; i < HOLE_COUNT; i++) {
    this.holes.push({ active: false, index: i });
  }
  this.showNextBtn = false;
  this.nextSpawnTime = 0;
  this.nextBtn = null;
  this.waitingForVideo = true;
  ads.showTopBanner();
  ads.showBottomBanner();
  const self = this;
  ads.showRewardedVideo().then(function () {
    self.waitingForVideo = false;
    self.nextSpawnTime = Date.now();
  }).catch(function () {
    self.waitingForVideo = false;
    self.nextSpawnTime = Date.now();
  });
};

PlayScene.prototype.onLeave = function () {
  ads.hidePlayBanners();
};

/** 当前关卡在 1–5 循环中的速度档位 1~5 */
PlayScene.prototype.getSpeedLevel = function () {
  const n = ((this.level - 1) % 5) + 1;
  return n;
};

/** 出现时长（毫秒）：档位 1 最慢，5 最快 */
PlayScene.prototype.getVisibleDuration = function () {
  const s = this.getSpeedLevel();
  const base = 1200;
  const step = 180;
  return Math.max(350, base - (s - 1) * step);
};

/** 下一个目标出现间隔（毫秒） */
PlayScene.prototype.getSpawnInterval = function () {
  const s = this.getSpeedLevel();
  const base = 650;
  const step = 80;
  return Math.max(280, base - (s - 1) * step);
};

PlayScene.prototype.update = function (time) {
  const ctx = this.getCtx();
  const { width, height } = this.getSize();
  const now = typeof time === 'number' ? time : Date.now();

  if (this.showNextBtn) {
    this.renderResult(ctx, width, height);
    return;
  }

  if (this.waitingForVideo) {
    ctx.fillStyle = '#1a3a1a';
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = '#fff';
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('广告加载中，请稍候…', width / 2, height / 2);
    return;
  }

  // 背景
  ctx.fillStyle = '#1a3a1a';
  ctx.fillRect(0, 0, width, height);

  const padding = 20;
  const areaW = width - padding * 2;
  const areaH = height - 180;
  const cellW = areaW / COLS;
  const cellH = areaH / ROWS;
  const radius = Math.min(cellW, cellH) * 0.35;

  // 关卡与积分
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 20px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('第 ' + this.level + ' 关', padding, 35);
  ctx.textAlign = 'right';
  ctx.fillText('本关击中：' + this.hitCount + ' / ' + TARGETS_PER_LEVEL + '    总积分：' + utils.getTotalScore(), width - padding, 35);

  // 洞口与目标
  this.holePositions = this.holePositions || [];
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const idx = row * COLS + col;
      const cx = padding + (col + 0.5) * cellW;
      const cy = 60 + (row + 0.5) * cellH;
          if (this.holePositions[idx] === undefined) {
        this.holePositions[idx] = { cx, cy, radius };
          }
      const pos = this.holePositions[idx];
      ctx.fillStyle = '#3d2817';
      ctx.beginPath();
      ctx.arc(pos.cx, pos.cy, pos.radius + 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#5c4033';
      ctx.lineWidth = 3;
      ctx.stroke();

      const hole = this.holes[idx];
      if (hole.active) {
        const elapsed = now - hole.showTime;
        if (elapsed >= hole.duration) {
          hole.active = false;
          this.spawnNext(now);
        } else {
          if (this._guziImageLoaded && this.guziImage && this.guziImage.width) {
            const sz = pos.radius * 2;
            ctx.drawImage(this.guziImage, pos.cx - pos.radius, pos.cy - pos.radius, sz, sz);
          } else {
            this.drawCartoonGuzi(ctx, pos.cx, pos.cy, pos.radius);
          }
        }
      }
    }
  }

  // 生成新目标
  if (this.spawned < TARGETS_PER_LEVEL && !this.hasActiveTarget() && now >= this.nextSpawnTime) {
    this.spawnNext(now);
  }

  // 本关 20 个已全部出现且没有正在显示的目标 → 显示下一关按钮
  if (this.spawned >= TARGETS_PER_LEVEL && !this.hasActiveTarget() && !this.showNextBtn) {
    this.showNextBtn = true;
  }
};

PlayScene.prototype.hasActiveTarget = function () {
  return this.holes.some(function (h) { return h.active; });
};

PlayScene.prototype.spawnNext = function (now) {
  if (this.spawned >= TARGETS_PER_LEVEL) return;
  const free = this.holes.map(function (h, i) { return h.active ? -1 : i; }).filter(function (i) { return i >= 0; });
  if (free.length === 0) return;
  const idx = free[Math.floor(Math.random() * free.length)];
  this.holes[idx].active = true;
  this.holes[idx].showTime = now;
  this.holes[idx].duration = this.getVisibleDuration();
  this.spawned++;
  this.nextSpawnTime = now + this.getSpawnInterval();
};

PlayScene.prototype.renderResult = function (ctx, width, height) {
  ctx.fillStyle = '#1a3a1a';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 24px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('第 ' + this.level + ' 关 完成', width / 2, 120);
  ctx.font = '18px sans-serif';
  ctx.fillText('本关击中：' + this.hitCount + ' 个   +' + this.hitCount + ' 积分', width / 2, 165);
  ctx.fillText('总积分：' + utils.getTotalScore(), width / 2, 200);
  const btnW = 180;
  const btnH = 48;
  const gap = 16;
  const bx = (width - btnW) / 2;
  const byNext = 260;
  this.nextBtn = { x: bx, y: byNext, w: btnW, h: btnH };
  ctx.fillStyle = '#c41e3a';
  ctx.fillRect(bx, byNext, btnW, btnH);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = '20px sans-serif';
  ctx.fillText('下一关', width / 2, byNext + btnH / 2);

  const byHome = byNext + btnH + gap;
  this.homeBtn = { x: bx, y: byHome, w: btnW, h: btnH };
  ctx.fillStyle = '#1a5490';
  ctx.fillRect(bx, byHome, btnW, btnH);
  ctx.strokeStyle = '#fff';
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.font = '20px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('回到首页', width / 2, byHome + btnH / 2);
};

PlayScene.prototype.hitTestTargets = function (x, y) {
  if (!this.holePositions) return -1;
  for (let i = 0; i < this.holes.length; i++) {
    if (!this.holes[i].active) continue;
    const pos = this.holePositions[i];
    const dx = x - pos.cx;
    const dy = y - pos.cy;
    if (dx * dx + dy * dy <= pos.radius * pos.radius) return i;
  }
  return -1;
};

PlayScene.prototype.isNextBtnHit = function (x, y) {
  const b = this.nextBtn;
  if (!b) return false;
  return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
};

PlayScene.prototype.isHomeBtnHit = function (x, y) {
  const b = this.homeBtn;
  if (!b) return false;
  return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
};

PlayScene.prototype.onTouchEnd = function (e) {
  const touch = e.changedTouches && e.changedTouches[0];
  if (!touch) return;
  const x = touch.clientX != null ? touch.clientX : touch.x;
  const y = touch.clientY != null ? touch.clientY : touch.y;

  if (this.showNextBtn) {
    if (this.isNextBtnHit(x, y)) {
      this.setScene('play', { level: this.level + 1 });
    } else if (this.isHomeBtnHit(x, y)) {
      this.setScene('home');
    }
    return;
  }

  const idx = this.hitTestTargets(x, y);
  if (idx >= 0) {
    this.holes[idx].active = false;
    this.hitCount++;
    utils.addScore(1);
    this.spawnNext(Date.now());
  }
};

module.exports = PlayScene;
